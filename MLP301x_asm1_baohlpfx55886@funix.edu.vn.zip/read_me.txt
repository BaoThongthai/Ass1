1. chạy file run_file_Python.bat để chạy trực tiếp file lastname_firstname_grade_the_exams.py ( chạy file này sẽ tự động kiểm tra cài đặt các thư viện đi kèm)

2. chạy run_JupyterLab.bat để chạy với JupyterLab, sau khi mở JupyterLab, chọn file lastname_firstname_grade_the_exams.ipynb và chạy hàm main ()

Cấu trúc 
1. Các hằng số
2. Các hàm xử lý file
3. Kiểm tra dữ liệu
4. Các hàm tính toán
5. Phân tích dữ liệu
6. Chương trình chính
